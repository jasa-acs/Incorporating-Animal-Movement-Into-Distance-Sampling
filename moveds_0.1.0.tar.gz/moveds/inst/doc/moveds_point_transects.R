## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----load_package--------------------------------------------------------
library(moveds)

## ----secret_data_load, echo = FALSE--------------------------------------
data("point_example")
cds1d <- point_example$cds1d
cds2d <- point_example$cds2d
mds2d <- point_example$mds2d
cds1d.gof <- point_example$cds1d.gof
cds2d.gof <- point_example$cds2d.gof
mds2d.gof <- point_example$mds2d.gof

## ----load_data-----------------------------------------------------------
data("point_example_dsdat")
str(point_example_dsdat) 
obs <- point_example_dsdat$obs
trans <- point_example_dsdat$trans

## ----summary_data--------------------------------------------------------
summary(obs)
nrow(obs)

## ----make_r--------------------------------------------------------------
distances <- sqrt(obs$x^2 + obs$y^2)

## ----plot_data, fig.width = 5, fig.height = 5----------------------------
hist(distances, main = "", xlab = "Radial distance")

## ----simulate_movement, fig.width = 5, fig.height = 5--------------------
fixed.sigma <- 1
num.tagged <- 2 
observation.times <- seq(0, 24*60, 15)
simulated.movement.data <- SimulateMovementData(num.tagged, observation.times, fixed.sigma)
str(simulated.movement.data)
plot(simulated.movement.data[[1]][,1:2], type = "b")
plot(simulated.movement.data[[2]][,1:2], type = "b")

## ------------------------------------------------------------------------
data("point_example_movedat")
str(point_example_movedat)

## ----load_distance-------------------------------------------------------
library(Distance)

## ----setup_cds1d_data----------------------------------------------------
region.table <- data.frame(Region.Label = 1, Area = 1000 * 1000)
sample.table <- data.frame(Sample.Label = trans[,1], Region.Label = 1, Effort = 1)
obs.table <- data.frame(object = 1:nrow(obs), Region.Label = 1, Sample.Label = obs[, 1])

## ----fit_cds1d, eval = FALSE---------------------------------------------
#  cds1d <- ds(distances,
#              truncation = 100,
#              transect = "point",
#              key = "hr",
#              adjustment = NULL,
#              region.table = region.table,
#              sample.table = sample.table,
#              obs.table = obs.table)
#  

## ----summary_cds1d-------------------------------------------------------
summary(cds1d)

## ----save_cds1d_info, echo=FALSE-----------------------------------------
N.cds1d <- round(as.numeric(cds1d$dht$individuals$N$Estimate),2) 
pdet.cds1d <- round(summary(cds1d)[[1]][[9]], 2) 
penc.cds1d <- round(pdet.cds1d * 100^2 * pi / 1000^2, 4) 
det.est <- round(as.numeric(exp(cds1d$ddf$ds$par)),2)

## ----plot_cds1d, eval = FALSE--------------------------------------------
#  plot(cds1d, pdf = TRUE)

## ----gof_cds1d, eval = FALSE---------------------------------------------
#  cds1d.gof <- ds.gof(cds1d)

## ----god_cds1d2----------------------------------------------------------
cds1d.gof

## ----aux-----------------------------------------------------------------
aux <- c(1000, 1000, 100, 0, 1)

## ----mds_data------------------------------------------------------------
ds <- list(data = obs,
           transect = trans,
           aux = aux,
           delta = c(5, 5*60),
           buffer = 0,
           hazardfn = 1,
           move = 0)

## ----dummy_move----------------------------------------------------------
move <- list(data = NULL)

## ----cds2d, eval = FALSE-------------------------------------------------
#  cds2d <- mds(ds, move, start = c(s = 4, d = 3))

## ----summary_cds2d-------------------------------------------------------
summary(cds2d)

## ----cds2d_N, echo = FALSE-----------------------------------------------
cds2d.N <- cds2d$result[3,1]

## ----plot_cds2d, eval = FALSE--------------------------------------------
#  plot(cds2d)

## ----gof_cds2d, eval = FALSE---------------------------------------------
#  cds2d.gof <- mds.gof(cds2d)

## ----gof_cds2d2----------------------------------------------------------
cds2d.gof

## ----mds2d_aux-----------------------------------------------------------
aux <- c(1000, 1000, 100, 0, 1)

## ----mds2d_data----------------------------------------------------------
ds <- list(data = obs,
           transect = trans,
           aux = aux,
           delta = c(5, 1),
           buffer = 5,
           hazardfn = 1,
           move = 1)

## ----mds2d_move----------------------------------------------------------
move <- list(data = point_example_movedat)

## ----mds2d_nomove, eval = FALSE------------------------------------------
#  move <- list(fixed.sd = 1)

## ----estdiff-------------------------------------------------------------
EstDiff(point_example_movedat)

## ----load_all_mods, eval = FALSE-----------------------------------------
#  data("example_mds_point_mods")

## ----fit_mds2d, eval = FALSE---------------------------------------------
#  mds2d <- mds(ds, move, start = c(s = 4, d = 3, sd = 1))

## ----summary_mds2d-------------------------------------------------------
summary(mds2d)

## ----mds2dN--------------------------------------------------------------
mds2d.N <- mds2d$result[4,1]

## ----plot_mds2d, eval = FALSE--------------------------------------------
#  plot(mds2d)

## ----mds2d_gof, eval = FALSE---------------------------------------------
#  mds2d.gof <- mds.gof(mds2d)

## ----mds_gof_summary-----------------------------------------------------
mds2d.gof

## ----detfnsplot, fig.width=7,fig.height=5--------------------------------
x <- seq(0, 100, 0.01)

g <- function(x, b, sigma) {1 - exp(-(x/sigma)^(-b))}
g.cds1d <- g(x, det.est[1], det.est[2])

est.cds2d <- s2sigmab(cds2d$result[1,1], cds2d$result[2,1], v = 0, T = 5*60)
g.cds2d <- g(x, est.cds2d[1], est.cds2d[2])

est.mds2d <- s2sigmab(mds2d$result[1,1], mds2d$result[2,1], v = 0, T = 5*60)
g.mds2d <- g(x, est.mds2d[1], est.mds2d[2])

plot(x, g.cds1d, type = "l", xlab = "Radial Distance", ylab = "Detection Probability")
lines(x, g.cds2d, col = "red")
lines(x, g.mds2d, col = "blue")

legend(80, 0.8, c("CDS1D", "CDS2D", "MDS2D"), col = c("black", "red", "blue"), lty = 1)

